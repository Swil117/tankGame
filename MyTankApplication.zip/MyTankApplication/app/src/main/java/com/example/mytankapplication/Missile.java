package com.example.mytankapplication;

public class Missile extends GameObject {

    public Missile(int owner, int x, int y, int direction, int pixelsPerBlock) {
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.owner = owner;
        speed = (int)(pixelsPerBlock / 10 * 2.5);
        isMoving = true;
    }

}
