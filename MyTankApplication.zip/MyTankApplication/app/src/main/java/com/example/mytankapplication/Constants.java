package com.example.mytankapplication;

public class Constants {
    //Tank stats:hit point, speed scalar, attack interval
    public static final int[][] States = {{2, 1, 15}, {3, 0 ,12}, {1, 2, 15}};
}
